﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            if (radioButton1.Checked == true)
            {
                string[] a = { "AMD FX-4300 OEM", "Intel Core i7-8700K",
                "AMD A6-9400 OEM"};
                listBox1.Items.AddRange(a);
            }
            else
                if (radioButton2.Checked == true)
            {
                string[] a = { "Palit GeForce GT 1030", "ASUS GeForce GT 730 Silent LP",
                    "ASUS GeForce GT 730"};
                listBox1.Items.AddRange(a);
            }
            else
                if (radioButton3.Checked == true)
            {
                string[] a = { "ASRock B460M Pro4", "Asus TUF GAMING B450-PLUS II",
                    "Gigabyte B550 AORUS ELITE V2"};
                listBox1.Items.AddRange(a);
            }
            else
            {
                string[] a = { "Crucial Ballistix DDR4 2x8Gb", "Kingston Fury Beast DDR4 2x8Gb",
                "Corsair Vengeance LPX DDR4 2x8Gb"};
                listBox1.Items.AddRange(a);
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (listBox1.Text == "AMD FX-4300 OEM")
            {
                string n = "5900";
                int m = Int32.Parse(n);
                textBox2.Text = m.ToString();
                textBox3.Text = (m * 0.013611).ToString();
                textBox4.Text = (m * 0.0120729).ToString();
            }
            else
            {
                if (listBox1.Text == "Intel Core i7-8700K")
                {
                    string n = "2300";
                    int m = Int32.Parse(n);
                    textBox2.Text = m.ToString();
                    textBox3.Text = (m * 0.013611).ToString();
                    textBox4.Text = (m * 0.0120729).ToString();
                }
                else
                {
                    if (listBox1.Text == "AMD A6-9400 OEM")
                    {
                        string n = "4500";
                        int m = Int32.Parse(n);
                        textBox2.Text = m.ToString();
                        textBox3.Text = (m * 0.013611).ToString();
                        textBox4.Text = (m * 0.0120729).ToString();
                    }
                    else


                           if (listBox1.Text == "Palit GeForce GT 1030")
                    {
                        string n = "1240";
                        int m = Int32.Parse(n);
                        textBox2.Text = m.ToString();
                        textBox3.Text = (m * 0.013611).ToString();
                        textBox4.Text = (m * 0.0120729).ToString();
                    }
                    else
                    {
                        if (listBox1.Text == "ASUS GeForce GT 730 Silent LP")
                        {
                            string n = "2400";
                            int m = Int32.Parse(n);
                            textBox2.Text = m.ToString();
                            textBox3.Text = (m * 0.013611).ToString();
                            textBox4.Text = (m * 0.0120729).ToString();
                        }
                        else
                        {
                            if (listBox1.Text == "ASUS GeForce GT 730")
                            {
                                string n = "2300";
                                int m = Int32.Parse(n);
                                textBox2.Text = m.ToString();
                                textBox3.Text = (m * 0.013611).ToString();
                                textBox4.Text = (m * 0.0120729).ToString();
                            }
                            else


                           if (listBox1.Text == "Palit GeForce GT 1030")
                            {
                                string n = "1240";
                                int m = Int32.Parse(n);
                                textBox2.Text = m.ToString();
                                textBox3.Text = (m * 0.013611).ToString();
                                textBox4.Text = (m * 0.0120729).ToString();
                            }
                            else
                            {
                                if (listBox1.Text == "ASUS GeForce GT 730 Silent LP")
                                {
                                    string n = "2400";
                                    int m = Int32.Parse(n);
                                    textBox2.Text = m.ToString();
                                    textBox3.Text = (m * 0.013611).ToString();
                                    textBox4.Text = (m * 0.0120729).ToString();
                                }
                                else
                                {
                                    if (listBox1.Text == "ASUS GeForce GT 730")
                                    {
                                        string n = "2300";
                                        int m = Int32.Parse(n);
                                        textBox2.Text = m.ToString();
                                        textBox3.Text = (m * 0.013611).ToString();
                                        textBox4.Text = (m * 0.0120729).ToString();
                                    }


                                }
                            }
                        }
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}