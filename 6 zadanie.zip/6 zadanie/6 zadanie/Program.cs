﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6_zadanie
{
    class Program
    {
        // Ввод ФИО и профессии
        static void addNames(string[] nNames, string[] secondN, string[] pProf, int i, int j, int size)
        {
            string f, u, o;

            Console.Write("Введите Фамилию: "); f = Console.ReadLine(); secondN[i] = f;
            Console.Write("Введите Имя: "); u = Console.ReadLine();
            Console.Write("Введите Отчество: "); o = Console.ReadLine();
            nNames[i] = f + " " + u + " " + o;
            Console.Write("Введите Профессию: "); pProf[j] = Console.ReadLine();
        }

        // Поиск по ФИО
        static void search(string[] addNames, string[] secondN, string[] addProfessions)
        {
            bool prov = false;
            string secondnames;
            Console.Write("Введите ФИО для поиска: ");
            secondnames = Console.ReadLine();

            while (prov == false)
            {
                for (int i = 1; i < secondN.Length; i++)
                {
                    if (secondnames == secondN[i])
                    {
                        Console.Write(addNames[i]);
                        Console.Write(" - ");
                        Console.WriteLine(addProfessions[i]);
                    }
                    else Console.WriteLine("Досье не найдено");
                    prov = true;
                }
            }

            Console.WriteLine("Нажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        // Вывод всех досье
        static void selectNames(string[] nNames, string[] pProf, int i)
        {
            Console.WriteLine("\n ФИО: {0}  Должность: {1}", nNames[i], pProf[i]);
        }

        // Изменение размера массива
        static void resizePlus(ref string[] resizeName, ref string[] secondname, ref string[] resizeProf, int newSize)
        {
            string[] newSizeName = new string[newSize];
            string[] newSizeProf = new string[newSize];
            string[] newSizeSecond = new string[newSize];

            for (int i = 0; i < resizeName.Length; i++)
            {
                newSizeName[i] = resizeName[i];
                newSizeProf[i] = resizeProf[i];
                newSizeSecond[i] = secondname[i];
            }

            resizeName = newSizeName;
            resizeProf = newSizeProf;
            secondname = newSizeSecond;
        }

        // Удаление досье
        static void removeAt(ref string[] removedName, ref string[] removedProf, int index)
        {
            string[] newRemovedName = new string[removedName.Length - 1];
            string[] newRemovedProf = new string[removedProf.Length - 1];

            for (int i = 0; i < index; i++)
                newRemovedName[i] = removedName[i];
            for (int i = index + 1; i < removedName.Length; i++)
                newRemovedName[i - 1] = removedName[i];
            for (int i = 0; i < index; i++)
                newRemovedProf[i] = removedProf[i];
            for (int i = index + 1; i < removedName.Length; i++)
                newRemovedProf[i - 1] = removedProf[i];
            
            removedName = newRemovedName;
            removedProf = newRemovedProf;
        }

        // Главная (основная программа)
        static void Main(string[] args)
        {
            Console.WriteLine("Хело мир!");

            int size = 1, i = 0, j=0, menu = 0, countProf = 1, number;
            string[] names = new string[size];
            string[] prof = new string[size];
            string[] secondname = new string[size];

            // Создание меню
            while (menu != 5)
            {
                countProf = 1;
                Console.Write("\n *** Отдел кадров ***"
                    + "\n 1 - Добавить ФИО и профессио"
                    + "\n 2 - Вывести весь список досье"
                    + "\n 3 - Поиск по фамилии"
                    + "\n 4 - Удаление досье"
                    + "\n 5 - Выход из программы" + "\n\n"
                    + "Выберите пункт меню\n");

                menu = Convert.ToInt32(Console.ReadLine());

                switch (menu)
                {
                    case 1:
                        {
                            size += 1;
                            i++;
                            j++;
                            resizePlus(ref names, ref secondname, ref prof, size);
                            addNames(names, secondname, prof, i, j, size);
                            Console.WriteLine("\n ФИО: {0}  Должность: {1}", names[i], prof[j]);
                            break;
                        }

                    case 2:
                        {
                            for (int countNames = 1; countNames < names.Length; countNames++)
                            {
                                Console.Write($"{countNames}. ");
                                Console.Write(names[countNames]);
                                Console.Write(" - ");
                                Console.WriteLine(prof[countProf]);
                                countProf++;
                            }
                            break;
                        }

                    case 3:
                        {
                            search(names, secondname, prof);
                            break;
                        }

                    case 4:
                        {
                            Console.WriteLine("Введите номер удаляемого досье");
                            number = Convert.ToInt32(Console.ReadLine());
                            removeAt(ref names, ref prof, number);
                            Console.WriteLine("Удаление досье прошло успешно");
                            Console.WriteLine("Нажмите любую клавишу для продолжения...");
                            break;
                        }
                }
            }
            Environment.Exit(0);
        }
    }
}