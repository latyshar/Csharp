﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GAME2._0
{
    public partial class Form1 : Form
    {
        bool goleft = false; // boolean контроль над игроком, идущим влево
        bool goright = false; // boolean контроль над игроком, идущим вправо
        bool jumping = false; // boolean проверяющая прыгнул игрок или нет
        bool hasKey = false; // значение по умолчанию, указывающее, есть ли у игрока ключ

        int jumpSpeed = 10; // скорость прыжка
        int force = 8; // "сила" прыжка (как высоко игрок может прыгнуть)
        int score = 0; // счет коинов

        int playSpeed = 18; //скорость игрока
        int backLeft = 8; // будет контролировать скорость окружающей среды относительно игрока



        public Form1()
        {
            InitializeComponent();
           
        }

        private void mainGameTimer(object sender, EventArgs e)
        {
            // привязка скорости прыжков с изображением игрока к местоположению
            player.Top += jumpSpeed;

            // обновление окна с изображением игрока (использование этой функции обновления позволяет немного уменьшить мерцание)
            player.Refresh();

            // если прыжок истинный (нажата клавиша вверх) и сила меньше 0
            // значение прыжка = false
           if (jumping && force < 0)
            {
                jumping = false; //чтобы персонаж не улетал
            }


            //В приведенном ниже операторе if, если прыжок истинен (нажата клавиша вверх), мы меняем скорость прыжка,
            //которая будет толкать игрока вверх, также уменьшаем силу на 1 при прыжке персонажа

            if (jumping)
            {
                jumpSpeed = -12;
                force -= 1;
            }
            else
            {
                // иначе оператор сработает, когда условие оператора if станет ложным
                // если персонаж не прыгает, то мы добавляем скорость прыжка.
                jumpSpeed = 12;
            }

            // если goleft равно true (нажата левая клавиша) и player.Left больше 10 пикселей (максимальное расстояние игрока от левой границы формы)
            // только после этого игрок перемещается влево 
            if (goleft && player.Left > 100)
            {
                player.Left -= playSpeed;
            }
            // выполнив оператор if выше, игрок не сможет вплотную подходить к границе формы слева

            // если goright  = true (нажата правая клавиша)
            // player.left плюс player.width плюс 100 меньше чем ширина формы
            // затем мы перемещаем игрока вправо 
            if (goright && player.Left + (player.Width + 100) < this.ClientSize.Width)
            {
                player.Left += playSpeed;

            }
            // выполнив оператор if выше, игрок не сможет вплотную подходить к границе формы справа


            // если goright = true (нажата правая клавиша) и расстояние границы фонового изображения от границы слева больше -1080
            // перемещаем фоновое изображение влево
            if (goright && background.Left > -1100)
            {
                background.Left -= backLeft;

                // цикл for ниже проверяет наличие платформ и монет на уровне
                //когда они будут найдены, они будут перемещаться влево с фоном
                foreach (Control x in this.Controls)
                {
                    if (x is PictureBox && x.Tag == "platform" || x is PictureBox && x.Tag == "coin" || x is PictureBox && x.Tag == "door" || x is PictureBox && x.Tag == "key")
                    {
                        x.Left -= backLeft;
                    }
                }

            }

            // если go left равно true (нажата левая клавиша) и расстояние границы фонового изображения от границы слева меньше 0
            // перемещаем фоновое изображение вправо
            if (goleft && background.Left < -10)
            {
                background.Left += backLeft;

                // ниже расположен цикл for, который проверяет наличие платформ и монет на уровне
                // когда они будут найдены, он переместит их всех вправо с фоном
                foreach (Control x in this.Controls)
                {
                    if (x is PictureBox && x.Tag == "platform" || x is PictureBox && x.Tag == "coin" || x is PictureBox && x.Tag == "door" || x is PictureBox && x.Tag == "key")
                    {
                        x.Left += backLeft;
                    }
                }
            }



            // цикл for проверяет все элементы управления в этой форме
            foreach (Control x in this.Controls)
            {
                // X - это picturebox, и он имеет тег "платформы"
                if (x is PictureBox && x.Tag == "platform")
                {
                    // если игрок находится на платформе и прыжок = false
                    if (player.Bounds.IntersectsWith(x.Bounds) && !jumping)
                    {
                        // тогда мы делаем следующее
                        force = 8; // высота прыжка 8
                        player.Top = x.Top - player.Height; // помещаем игрока поверх платформы
                        jumpSpeed = 0; // скорость прыжка 0
                    }
                }
                // если у picture box тэг coin
                if (x is PictureBox && x.Tag == "coin")
                {
                    //теперь, если игрок сталкивается с картинкой монеты
                    if (player.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(x); // то мы удаляем изображение монеты
                        score++; // добавляем 1 к счету
                        label3.Text=score.ToString();// выводим на экран кол-во очков
                    }
                }
            }

            // если игрок столкнулся с дверью и у него есть ключ

            if (player.Bounds.IntersectsWith(door.Bounds) && hasKey)
            {
                //то меняем изображение двери на открытую
                door.Image = Properties.Resources.door_open;
                // останавливаем таймер
                gameTimer.Stop();
                MessageBox.Show("Уровень пройден"); // показываем MessageBox

                Application.Exit();//и выходим из приложения

            }

            // если игрок сталкивается с картинкой ключа

            if (player.Bounds.IntersectsWith(key.Bounds))
            {

                //  мы удаляем key
                this.Controls.Remove(key);
                // изменяем key на true
                hasKey = true;
            }


            // когда игрок умирает

            // если игрок опускается ниже высоты формы, то мы начинаем игру заново
            if (player.Top + player.Height > this.ClientSize.Height + player.Height)
            {
                gameTimer.Stop(); // останавливаем таймер
                MessageBox.Show("бобик сдох"); // выводим message box
                Form1 newWindow = new Form1(); // обновляем форму
                newWindow.Show();
                this.Hide();
            }

        }

        private void keyisdown(object sender, KeyEventArgs e)
        {
            // если игрок нажал левую клавишу
            //  то мы устанавливаем goleft  = true
            if (e.KeyCode == Keys.Left)
            {
                goleft = true;
                player.Image = Properties.Resources.playerleft; //меняем картинку на игрока, который ходит влево

            }
            // если игрок нажал правую клавишу           

            if (e.KeyCode == Keys.Right)
            {
                // тогда устанавливаем goright = true
                goright = true;
                player.Image = Properties.Resources.player1; //меняем картинку на игрока, который ходит вправо
            }

            //если игрок нажал клавишу вверх и прыжок  = false 

            if (e.KeyCode == Keys.Up && !jumping)
            {
                // то jumping = true (это популярный метод, чтобы остановить игроков от двойного, тройного прыжка в игре)
                jumping = true;
            }

        }

        private void keyisup(object sender, KeyEventArgs e)
        {
            // если клавиша LEFT отпущена, мы устанавливаем для параметра goleft = false
            if (e.KeyCode == Keys.Left)
            {
                goleft = false;
            }
            // если клавиша RIGHT отпущена, мы устанавливаем для параметра goright = false
            if (e.KeyCode == Keys.Right)
            {
                goright = false;
            }
            //когда клавиши отпущены, мы проверяем, является ли прыжок истинным
            // если да, то нужно вернуть значение false, чтобы игрок мог прыгнуть снова
            if (jumping)
            {
                jumping = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

           //прозрачный фон у картинок
            background.Controls.Add(fonari);
            background.Controls.Add(fonari1);
            background.Controls.Add(fonari2);
            background.Controls.Add(plakat1);
            background.Controls.Add(plakat3);

        }

      

     

        private void pictureBox29_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox28_Click(object sender, EventArgs e)
        {

        }
    }
}
