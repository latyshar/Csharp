﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace captcha
{
    public partial class Form1 : Form
    {
        private string CreatedCaptcha; // здесь хранится текст с каптчи
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.CreatedCaptcha = this.CreateCaptcha();
            panel2.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
        }
        
        public string CreateCaptcha() // создание каптчи
        {
            // массив путей к картинкам 
            var path = Application.StartupPath;
            string[] files = Directory.GetFiles(@path, "*.png", SearchOption.AllDirectories);

            // выбор случайной картинки
            Random r = new Random();
            int id = r.Next(0, files.Length);
            Bitmap yourPic = new Bitmap(files[id]);

            // нахождение текста каптчи
            FileInfo yourFile = new FileInfo(files[id]);
            string yourText = yourFile.Name;
            yourText = yourText.Replace(".png", "");

            // отображение каптчи
            pictureBox1.Image = yourPic;
            textBox4.Text = ""; // текст с картинки, который вводит пользователь
            textBox3.Text = ""; // пароль

            // возвращение текста к каптче
            return yourText;
        }

        private bool Proverka(string name, string login, string pass) // проверка введенных пользователем данных
        {
            if (name.Length < 3) // проверка поля Имя
            {
                this.CreatedCaptcha = this.CreateCaptcha();
                this.textBox1.BackColor = Color.Red;
                int num = (int)MessageBox.Show("Имя пользователя должно быть длиннее 3-х символов!");
            }
            else if (login.Length < 4) // проверка поля Логин
            {
                this.CreatedCaptcha = this.CreateCaptcha();
                this.textBox2.BackColor = Color.Red;
                int num = (int)MessageBox.Show("Логин должен быть длиннее 4-х символов!");
            }
            else
            {
                if (pass.Length >= 4) // проверка поля Пароль
                    return true;
                this.CreatedCaptcha = this.CreateCaptcha();
                this.textBox3.BackColor = Color.Red;
                int num = (int)MessageBox.Show("Пароль должен быть длиннее 4-х символов!");
            }
            return false;
        }
          private void button1_Click(object sender, EventArgs e)
        {
            if (!Proverka(textBox1.Text, textBox2.Text, textBox3.Text)) // обращение к функции с проверкой полей ввода
                return;
            
            if (!this.textBox4.Text.Equals(this.CreatedCaptcha)) // проверка введенного текста капчи
            {
                button2.Visible = true;
                button3.Visible = true;
                label6.Visible = true;
                label7.Visible = false;
            }
            else
            {
                button4.Visible = true;
                label7.Visible = true;
            }
          panel2.Visible = true;
         } 

         private void button2_Click(object sender, EventArgs e) // кнопка Вернуться (при неуспешном вводе текста с каптчи)
        {
            this.CreatedCaptcha = this.CreateCaptcha();
            panel2.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            label6.Visible = false;
        }     

        private void button4_Click(object sender, EventArgs e) // кнопка Выйти (при успешной регистрации)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e) // кнопка ОК (при неуспешном вводе текста с каптчи; кнопка выхода)
        {
            Application.Exit();
        }

        private void textBox1_Click(object sender, EventArgs e) // отбеливание поля ввода написании имени
        {
            this.textBox1.BackColor = Color.White;
        }

        private void textBox2_Click(object sender, EventArgs e) // отбеливание поля ввода написании логина
        {
            this.textBox2.BackColor = Color.White;
        }

        private void textBox3_Click(object sender, EventArgs e) // отбеливание поля ввода написании пароля
        {
            this.textBox3.BackColor = Color.White;
        } 
        private void panel2_Paint(object sender, PaintEventArgs e) {}
    }
}   