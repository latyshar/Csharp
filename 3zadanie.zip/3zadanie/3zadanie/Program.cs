﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3zadanie
{
    class Program
    {
        static void Main(string[] args)
        {
            string code = "kitty0176kat"; // секретный пароль
            string mess = "(=；I；=) (='w'=) Еда для настоящих кошек! (=^..^=) (＾* w *＾)"; // тайное сообщение
            int k = 0; // счетчик цикла
           
            Console.Write("Введите пароль: ");
            string parol = Console.ReadLine(); // ввод секретного пароля

            if (parol == code) // условие при первом вводе пароля (сравнение введеного пароля с действующем)
            {
                Console.WriteLine(mess); // вывод тайного сообщения
                Console.WriteLine("***");
                Console.ReadLine();
            }
            else { 
                while (k < 2) // цикл оп.
                {
                    k++; // увеличение счетчика
                    Console.Write("Введите пароль еще раз: ");
                    parol = Console.ReadLine();
                    if (parol == code) // очередное сравнение
                    {
                        Console.WriteLine(mess);
                        break; // цикл хопа.
                    }
                } 
            }
        }
    }
}

