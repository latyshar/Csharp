﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_zadanie
{
    class Program
    {
        static void Main(string[] args)
        {
            int curs = 100; // объявление переменной "курс золота по отношению к кристаллу"

            Console.WriteLine("Продавец: - Скажите, сколько у Вас золота? ");
            Console.Write("Вы: - ");
            int zol = int.Parse(Console.ReadLine()); // ввод пользователем количества золота

            Console.WriteLine("Продавец: - Курс валюты: 1 кристалл = 100 золото");

            Console.WriteLine("Продавец: - Сколько кристаллов Вы хотите приобрести?");
            Console.Write("Вы: - ");
            int crist = int.Parse(Console.ReadLine()); // ввод пользователем число кристаллов
            
            int ost = 0; // объявление переменной "остаток золота"
            ost = zol - curs * crist; // подсчет остатка золота

            if (ost >= 0)
            {
                // когда обмен работает
                Console.WriteLine("Продавец: - На Вашем счету осталось " + ost + " золота и " + crist + " кристаллов");
            }
            else
            {
                // когда обмен не проходит по недостаточности средств (золота)
                Console.WriteLine("Продавец: - На Вашем счету недостаточно золота на приобретение " + crist + " кристаллов");
                Console.WriteLine("Продавец: - У Вас всего " + zol + " золота");
            }
        }
    }
}
